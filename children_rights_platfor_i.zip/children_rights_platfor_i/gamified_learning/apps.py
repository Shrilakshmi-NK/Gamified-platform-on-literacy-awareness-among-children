from django.apps import AppConfig


class GamifiedLearningConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gamified_learning'
